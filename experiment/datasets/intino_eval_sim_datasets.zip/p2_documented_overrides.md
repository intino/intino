# Documented overrides (simulated)

This file lists intentional overrides of inherited rules/validators for each DSML.

## metta
- Override: `MR-Proportionality-Tolerance` (tightens tolerance defaults for teaching examples)
- Override: `Test-Structure-MinCardinality` (enforces at least one `Then` clause)

## konos
- Override: `Auth-Visibility` (adds domain rule for required auth on public endpoints)
- Override: `Resource-Path-Normalization` (specializes URL normalization to match API gateway constraints)

## contracts
- Override: `Clause-Optionality` (supports nested optional clauses with explicit `:Required` modifier)
- Override: `Party-Identity-Format` (adds stricter ID format constraints)

Unintended divergences flagged by Tara's Checker: 0 (simulated).
