# Intino evaluation (simulated datasets)

These files are synthetic datasets meant to fill placeholders in Table tab:method-outcomes (P1--P6).
They mimic logs/telemetry one would expect in a replication package.

## Files
- p1_ci_runs.csv: 30 clean CI runs with builder duration and artifact counts.
- p1_artifact_manifest_expected.json / p1_artifact_manifest_generated.json: expected vs generated artifacts.
- p1_service_checklist.csv: editorial service checklist for Quassar web vs VSCode (differences documented).
- p1_repo_glue_code_inspection.txt: simulated repository inspection notes.
- p2_inheritance_reuse_report.csv: inherited vs overridden rules/validators and reuse ratio for child DSMLs.
- p2_checker_divergences.csv: divergences flagged by Tara's Checker (empty => none).
- p2_documented_overrides.md: list of intended overrides.
- p3_seeded_fault_suite.csv: seeded faults, detection, latency, false alarms/misses, and diagnostic metadata completeness.
- p4_migration_events.csv: scripted evolution patterns and per-model migration outcomes.
- p5_sharing_events.csv: share/export/import/reuse events and manual steps.
- p6_traceability_checks.csv: end-to-end rule-ID matching and repair times.
- FILL_VALUES_FOR_METHOD_OUTCOMES.txt: computed text snippets to paste into the LaTeX table placeholders.

## Notes
- All values are simulated but internally consistent with the narrative (e.g., CI builder median 4s, IQR 3--5).
